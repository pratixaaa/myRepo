namespace ShipandPort
{
    public class Port
    {
        public int PortId { get; set; }
        public string PortName { get; set; }
        public double PortLatitude { get; set; }
        public double PortLongitude { get; set; }
        public double PortDistance { get; set; }
    }

}